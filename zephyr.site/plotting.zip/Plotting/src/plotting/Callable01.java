package plotting;

import rlpark.plugin.utils.logger.Logged;
import rlpark.plugin.utils.logger.LoggedManager;
import rlpark.plugin.utils.time.Clock;
import zephyr.plugin.common.synchronization.Callable;
import zephyr.plugin.plotting.ZephyrPluginPlotting;

/*
 * Implement the interface Callable to provide the extension
 * zephyr.plugin.common.synchronization.callable
 * that is an instance to call when Zephyr is ready to collect 
 * the data
 */
public class Callable01 implements Callable {
  private final double[] a = new double[10];

  /*
   * Clock from Zephyr: it will tell Zephyr the current time for the data
   * associated with this clock and when these data have been updated and have
   * to be collected
   */
  private final Clock clock = new Clock();

  /*
   * A public constructor of this class with no argument needs to exist so that
   * the Eclipse framework is able to create it through reflexivity.
   */
  public Callable01() {
    /*
     * Create a new LoggedManager, that is a collection of data being collected.
     * The label of the clock is "Callable01" (this label will be used as a
     * prefix) An instance of Clock is the second argument
     */
    LoggedManager logger = ZephyrPluginPlotting.traces().addClock("Callable01", clock);
    /*
     * Call a method that registers an instance of Logged (representing a data
     * being collected) for every element of the array a into logger
     */
    addToLogger(logger, a);
  }

  private void addToLogger(LoggedManager logger, final double[] array) {
    for (int i = 0; i < array.length; i++) {
      final int dataIndex = i;
      /*
       * Register an anonymous class implementing Logged (and in particular the
       * loggedValue method that returns the current value of the data being
       * collected) that is going to return the current value of the element at
       * index dataIndex in the array a with the label
       * "a[index of the element in a]" The label is the first argument, the
       * instance of Logged is the second.
       */
      logger.addLog("a[" + i + "]", new Logged() {
        /*
         * loggedValue should return the value of the data being collected at
         * time stepTime. Note that stepTime is just here for information and
         * will be equal to 0, 1, 2,...
         * 
         * Do not return null: this comes from an old code and I forgot to
         * change it. It will probably be changed/fixed in a later version.
         */
        public double loggedValue(int stepTime) {
          return array[dataIndex];
        }
      });
    }
  }

  /*
   * This methods is called by Zephyr when it is ready to collect some more data
   */
  public void call() {
    /*
     * Update the value in the array a
     */
    for (int i = 0; i < a.length; i++)
      a[i] = Math.cos(clock.time() * 50 + i);
    /*
     * Tick moves the clock to the next time step. Note that the LoggedManager
     * associated with is hooked to a corresponding event and will collect (but
     * not display) the data (in this thread) by calling all the loggedValue
     * methods of all the Logged instance previously registered
     */
    clock.tick();
  }
}
